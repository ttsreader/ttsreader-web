---
title: "The TTSReader team"
description: "Creator of TTSReader"
date: 2023-02-27T19:25:12+02:00
lastmod: 2023-02-27T19:25:12+02:00
draft: false
images: []
---

Creator of TTSReader.

[@speechlogger](https://twitter.com/speechlogger)
