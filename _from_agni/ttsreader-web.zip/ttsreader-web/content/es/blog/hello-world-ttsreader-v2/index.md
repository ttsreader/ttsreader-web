---
title: "Say hello to our new website 👋"
description: "Introducing the new website"
excerpt: "Introducing the new website"
date: 2023-05-04T09:19:42+01:00
lastmod: 2023-05-04T09:19:42+01:00
draft: false
weight: 50
images: []
categories: ["News"]
tags: [""]
contributors: ["Ronen Rabinovici"]
pinned: false
homepage: false
---

Introducing our new website. Hopefully it goes without errors. It is still growing - lots of content will be added over the next few weeks.

In case you need the older version of the website, it is still available at [https://ttsreader.com/legacy/](https://ttsreader.com/legacy/).
