---
title: "Classic Player"
description: "Classic Text to Speech Player. Reads out loud texts, pdfs, ebooks & websites. Battle tested for years."
lead: ""
date: 2023-02-24T08:50:23+02:00
lastmod: 2023-02-24T08:50:23+02:00
draft: false
images: []
layout: embedded
embedded: "player"
sitemap:
  priority: 0.9
---
