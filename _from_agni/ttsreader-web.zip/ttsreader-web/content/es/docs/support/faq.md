---
title: "FAQ"
description: "Answers to frequently asked questions."
lead: "Answers to frequently asked questions."
date: 2020-10-06T08:49:31+00:00
lastmod: 2020-10-06T08:49:31+00:00
draft: false
images: []
menu:
  docs:
    parent: "support"
weight: 210
toc: false
---

### Visit our complete [FAQ](/faqs/) page for more answers to frequently asked questions. We're working to update it for the new player.

