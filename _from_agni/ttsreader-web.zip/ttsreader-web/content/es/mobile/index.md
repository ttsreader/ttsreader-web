---
title: "Text to Speech for Mobile Devices"
description: "Get the TTSReader mobile app, for Android or iOS"
date: 2023-02-27T19:25:12+02:00
lastmod: 2023-02-27T19:25:12+02:00
draft: false
images: []
type: mobile
sitemap:
  priority: 0.8
---


