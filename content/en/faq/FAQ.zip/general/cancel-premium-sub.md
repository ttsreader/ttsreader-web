---
title: "How Do I Cancel Premium Monthly Subscription?"
description: "How Do I Cancel Premium Monthly Subscription?"
date: 2023-02-12T15:22:20+01:00
lastmod: 2025-05-18T15:22:20+01:00
draft: false
images: []
menu:
  faq:
    parent: "general"
weight: 501
toc: false
---

## Question

How Do I Cancel Premium Monthly Subscription?


## Answer

Simply go to [New Player](/player/) - there:
1. Sign in to your account.
2. Click on the "Manage Premium" button - in the left side-bar menu (if sidebar menu is closed, open it first).
3. Click on "Subscription - click here to view & manage"
4. Click on "Cancel Subscription". Be ware it is effective immediately and cannot be undone.
